"""อ่าน Excel ตรวจข้อมูล และบันทึกลง SQLite แบบครบทั้งไฟล์หรือไม่บันทึกเลย."""

from __future__ import annotations

import hashlib
import logging
import shutil
import sqlite3
from contextlib import closing
from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal, InvalidOperation
from io import BytesIO
from pathlib import Path
from uuid import uuid4
from zipfile import BadZipFile
from xml.etree.ElementTree import ParseError

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils.exceptions import InvalidFileException


HEADERS = ("product_id", "product_name", "category", "price", "quantity")
LOGGER = logging.getLogger(__name__)
MAX_STOCK = 9_223_372_036_854_775_807  # ขอบเขต INTEGER ของ SQLite


class InvalidData(ValueError):
    """ข้อมูลจาก Excel ไม่ตรงกับรูปแบบที่ระบบต้องการ."""


class FileChanging(OSError):
    """ไฟล์กำลังถูกแก้ไข ให้รอตรวจใหม่ในรอบถัดไป."""


@dataclass
class ImportResult:
    filename: str
    status: str
    inserted: int = 0
    updated: int = 0
    unchanged: int = 0
    message: str = ""
    archive: str = ""


@dataclass(frozen=True)
class StockReduction:
    product_id: str
    product_name: str
    removed: int
    before: int
    after: int


def now_text() -> str:
    # เก็บเวลาท้องถิ่นของเครื่องพร้อมเขตเวลา เช่น +07:00
    return datetime.now().astimezone().isoformat(timespec="seconds")


def signature(path: Path) -> tuple[int, int]:
    stat = path.stat()
    return stat.st_size, stat.st_mtime_ns


def required_text(value, label: str, row: int, max_length: int) -> str:
    if not isinstance(value, str) or not value.strip():
        raise InvalidData(f"แถว {row}: {label} ต้องเป็นข้อความและห้ามว่าง")
    value = value.strip()
    if len(value) > max_length:
        raise InvalidData(f"แถว {row}: {label} ยาวได้ไม่เกิน {max_length} ตัวอักษร")
    return value


def number(value, label: str, row: int) -> Decimal:
    # ไม่ยอมรับข้อความ ตัวเลขแบบ True/False วันที่ หรือค่าที่ไม่ใช่จำนวนจำกัด
    if isinstance(value, bool) or not isinstance(value, (int, float, Decimal)):
        raise InvalidData(f"แถว {row}: {label} ต้องเป็นเซลล์ตัวเลข")
    try:
        result = Decimal(str(value))
    except InvalidOperation as exc:
        raise InvalidData(f"แถว {row}: {label} ไม่ใช่ตัวเลขที่ถูกต้อง") from exc
    if not result.is_finite() or result < 0 or result > 1_000_000_000:
        raise InvalidData(f"แถว {row}: {label} ต้องอยู่ระหว่าง 0 ถึง 1,000,000,000")
    return result


def read_products(content: bytes) -> list[tuple]:
    """คืนรายการ (รหัส, ชื่อ, หมวดหมู่, ราคาสตางค์, จำนวน) หลังตรวจทุกแถว."""
    try:
        workbook = load_workbook(BytesIO(content), read_only=True, data_only=False)
    except (BadZipFile, InvalidFileException, KeyError, ValueError, ParseError) as exc:
        raise InvalidData("อ่าน Excel ไม่ได้: ต้องเป็นไฟล์ .xlsx ที่เปิดได้ตามปกติ") from exc

    try:
        if "Products" not in workbook.sheetnames:
            raise InvalidData("ไม่พบชีต Products กรุณาใช้ไฟล์ตัวอย่างเป็นต้นแบบ")
        sheet = workbook["Products"]
        rows = sheet.iter_rows()
        header = next(rows, ())
        names = tuple(str(cell.value).strip() if cell.value is not None else ""
                      for cell in header)
        if names[:5] != HEADERS or any(names[5:]):
            raise InvalidData("หัวตารางแถว 1 ต้องเป็น: " + ", ".join(HEADERS))

        products = []
        seen = set()
        for row_number, cells in enumerate(rows, start=2):
            values = [cell.value for cell in cells]
            if all(value is None or value == "" for value in values):
                continue
            if any(cell.data_type in ("f", "e") for cell in cells):
                raise InvalidData(f"แถว {row_number}: พบสูตรหรือค่า Error ให้ใช้ค่าข้อมูลโดยตรง")
            if any(value is not None and value != "" for value in values[5:]):
                raise InvalidData(f"แถว {row_number}: ให้ใส่ข้อมูลเฉพาะคอลัมน์ A ถึง E")
            values += [None] * max(0, 5 - len(values))
            product_id = required_text(values[0], "product_id", row_number, 40)
            name = required_text(values[1], "product_name", row_number, 200)
            category = required_text(values[2], "category", row_number, 100)
            price = number(values[3], "price", row_number)
            quantity = number(values[4], "quantity", row_number)
            if price * 100 != (price * 100).to_integral_value():
                raise InvalidData(f"แถว {row_number}: price มีทศนิยมได้ไม่เกิน 2 ตำแหน่ง")
            if quantity != quantity.to_integral_value():
                raise InvalidData(f"แถว {row_number}: quantity ต้องเป็นจำนวนเต็ม")
            if product_id in seen:
                raise InvalidData(f"แถว {row_number}: product_id {product_id} ซ้ำภายในไฟล์")
            seen.add(product_id)
            products.append((product_id, name, category, int(price * 100), int(quantity)))
        if not products:
            raise InvalidData("ไม่มีแถวข้อมูลสินค้า")
        return products
    except (BadZipFile, KeyError, ParseError) as exc:
        raise InvalidData("โครงสร้างภายในไฟล์ Excel ไม่สมบูรณ์ กรุณาบันทึกไฟล์ใหม่") from exc
    finally:
        workbook.close()


class InventoryImporter:
    def __init__(self, root: Path):
        self.root = Path(root).resolve()
        for name in ("inbox", "processing", "processed", "failed", "data", "logs", "exports"):
            (self.root / name).mkdir(parents=True, exist_ok=True)
        self.db_path = self.root / "data" / "inventory.db"
        self.previous_stats = {}
        schema = Path(__file__).with_name("schema.sql").read_text(encoding="utf-8")
        with closing(self.connect()) as connection:
            connection.executescript(schema)

    def connect(self):
        connection = sqlite3.connect(self.db_path, timeout=10)
        connection.row_factory = sqlite3.Row
        return connection

    def _history(self, connection, result: ImportResult, digest: str, delivery_id=None):
        cursor = connection.execute(
            """INSERT INTO import_history
               (filename, file_hash, status, inserted, updated, unchanged, message, imported_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (result.filename, digest, result.status, result.inserted, result.updated,
             result.unchanged, result.message, now_text()),
        )
        if delivery_id is not None:
            connection.execute(
                "INSERT INTO import_deliveries (delivery_id, file_hash, history_id) VALUES (?, ?, ?)",
                (delivery_id, digest, cursor.lastrowid),
            )

    def import_bytes(self, filename: str, content: bytes, delivery_id=None) -> ImportResult:
        """บวกจำนวนรับเข้าและบันทึกประวัติพร้อมกัน; แต่ละการเรียกคืองานใหม่

        delivery_id ใช้ภายในสำหรับลองงานค้างเดิมซ้ำอย่างปลอดภัยเท่านั้น
        ไม่ใช้ hash ห้ามการอัปโหลดไฟล์เดิมเป็นงานใหม่
        """
        digest = hashlib.sha256(content).hexdigest()
        with closing(self.connect()) as connection:
            # ล็อกตั้งแต่อ่านยอดเดิมจนบวกและ commit ป้องกันยอดสูญหายจากงานพร้อมกัน
            with connection:
                connection.execute("BEGIN IMMEDIATE")
                if delivery_id is not None:
                    known = connection.execute(
                        """SELECT d.file_hash, h.status, h.message FROM import_deliveries d
                           JOIN import_history h ON h.id=d.history_id WHERE d.delivery_id=?""",
                        (delivery_id,),
                    ).fetchone()
                    if known:
                        if known["file_hash"] != digest:
                            raise InvalidData("ไฟล์ใน processing ถูกแก้ไขหลังบันทึกแล้ว กรุณาย้ายออกจาก processing "
                                              "และเลือกนำเข้าผ่าน UI ใหม่หากต้องการรับสินค้าเพิ่ม")
                        status = "duplicate" if known["status"] == "success" else "error"
                        message = ("งานนี้บันทึกแล้ว กำลังเก็บไฟล์ค้างโดยไม่บวกจำนวนอีกครั้ง"
                                   if status == "duplicate" else known["message"])
                        return ImportResult(filename, status, message=message)
                try:
                    products = read_products(content)
                    changes = []
                    for product in products:
                        existing = connection.execute(
                            "SELECT product_name, category, price_satang, quantity FROM products WHERE product_id=?",
                            (product[0],),
                        ).fetchone()
                        total = product[4] + (existing["quantity"] if existing else 0)
                        if total > MAX_STOCK:
                            raise InvalidData(f"รหัส {product[0]}: จำนวนสะสมเกินขอบเขตฐานข้อมูล")
                        changes.append(((*product[:4], total), existing))
                except InvalidData as exc:
                    result = ImportResult(filename, "error", message=str(exc))
                    self._history(connection, result, digest, delivery_id)
                    return result

                result = ImportResult(filename, "success")
                for product, existing in changes:
                    if existing is None:
                        connection.execute("INSERT INTO products VALUES (?, ?, ?, ?, ?, ?)",
                                           (*product, now_text()))
                        result.inserted += 1
                    elif tuple(existing) != product[1:]:
                        connection.execute(
                            """UPDATE products SET product_name=?, category=?, price_satang=?,
                               quantity=?, updated_at=? WHERE product_id=?""",
                            (*product[1:], now_text(), product[0]),
                        )
                        result.updated += 1
                    else:
                        result.unchanged += 1
                result.message = (f"รับเข้าเพิ่ม {sum(p[4] for p in products):,} ชิ้น"
                                  f" | รหัสใหม่ {result.inserted} รายการ | อัปเดต {result.updated} รายการ"
                                  f" | ค่าเดิม {result.unchanged} รายการ")
                self._history(connection, result, digest, delivery_id)
                return result

    def process_file(self, path: Path) -> ImportResult:
        path = Path(path).resolve()
        before = signature(path)
        content = path.read_bytes()
        if signature(path) != before:
            raise FileChanging("ไฟล์กำลังเปลี่ยนแปลง")
        processing = self.root / "processing"
        if path.parent != processing:
            # ชื่องานไม่ซ้ำและคงอยู่บนดิสก์ แม้ปิดโปรแกรมก่อน/หลัง commit
            claimed = processing / f"{uuid4().hex}_{path.name}"
            path.replace(claimed)
            path = claimed
            if signature(path) != before:
                raise FileChanging("ไฟล์กำลังเปลี่ยนแปลง จะอ่านงานค้างรอบถัดไป")
        delivery_id, separator, filename = path.name.partition("_")
        if not separator or len(delivery_id) != 32 or any(c not in "0123456789abcdef" for c in delivery_id):
            raise InvalidData("ไม่รู้จักชื่องานใน processing กรุณาย้ายไฟล์ไป inbox แล้วลองใหม่")
        result = self.import_bytes(filename, content, delivery_id=delivery_id)
        LOGGER.info("%s | %s | %s", result.status, path.name, result.message)

        # ห้ามย้ายไฟล์ที่ถูกแก้ไขหลังอ่าน เพื่อให้ผู้ใช้ตรวจสอบฉบับที่เปลี่ยน
        if signature(path) != before:
            result.message += " | ไฟล์ใน processing มีการแก้ไขระหว่างนำเข้า กรุณาตรวจสอบก่อนนำเข้าใหม่"
            return result
        folder = "failed" if result.status == "error" else "processed"
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        target = self.root / folder / f"{stamp}_{uuid4().hex[:8]}_{filename}"
        try:
            shutil.move(str(path), str(target))
            result.archive = str(target)
            if result.status == "error":
                target.with_suffix(".error.txt").write_text(result.message + "\n", encoding="utf-8")
        except OSError as exc:
            # งานค้างอยู่ใน processing; delivery_id กันบวกซ้ำ แม้ปิดเปิดโปรแกรม
            result.message += f" | ย้ายไฟล์/เขียนรายงานไม่ได้: {exc} (ตรวจ logs/system.log)"
            LOGGER.warning("%s", result.message)
        return result

    def import_selected_file(self, source: Path) -> ImportResult:
        """นำเข้าไฟล์ที่เลือกจาก UI โดยเก็บต้นฉบับภายนอก inbox ไว้ที่เดิม."""
        source = Path(source).resolve()
        if source.suffix.lower() != ".xlsx" or source.name.startswith("~$"):
            raise InvalidData("กรุณาเลือกไฟล์ Excel .xlsx ที่บันทึกและปิดเรียบร้อยแล้ว")
        if source.parent == self.root / "inbox":
            return self.process_file(source)
        before = signature(source)
        content = source.read_bytes()
        if signature(source) != before:
            raise FileChanging("ไฟล์กำลังเปลี่ยนแปลง กรุณาบันทึกและปิด Excel แล้วลองใหม่")
        target = self.root / "inbox" / f"{uuid4().hex[:12]}_{source.name}"
        temporary = target.with_suffix(".part")
        try:
            temporary.write_bytes(content)
            temporary.replace(target)
        finally:
            temporary.unlink(missing_ok=True)
        return self.process_file(target)

    def import_selected_files(self, sources) -> list[ImportResult]:
        """นำเข้าทีละไฟล์ตามลำดับที่เลือก; ไฟล์ผิดไม่ขัดขวางไฟล์ถัดไป."""
        results = []
        for source in sources:
            try:
                results.append(self.import_selected_file(Path(source)))
            except (OSError, sqlite3.Error, InvalidData) as exc:
                LOGGER.exception("ยังนำเข้า %s ไม่สำเร็จ", Path(source).name)
                results.append(ImportResult(Path(source).name, "retry", message=str(exc)))
        return results

    def scan_once(self, require_stable: bool = False) -> list[ImportResult]:
        """โหมดอัตโนมัติรอให้ขนาดและเวลาแก้ไขไฟล์คงที่ 2 รอบก่อนอ่าน."""
        results = []
        paths = [p for folder in ("processing", "inbox")
                 for p in sorted((self.root / folder).iterdir())
                 if p.is_file() and p.suffix.lower() == ".xlsx" and not p.name.startswith("~$")]
        current_paths = set(paths)
        self.previous_stats = {p: s for p, s in self.previous_stats.items() if p in current_paths}
        for path in paths:
            try:
                current = signature(path)
                previous = self.previous_stats.get(path)
                self.previous_stats[path] = current
                if require_stable and previous != current:
                    continue
                results.append(self.process_file(path))
            except FileChanging:
                continue
            except (OSError, sqlite3.Error, InvalidData) as exc:
                # เก็บงานไว้ใน inbox หรือ processing เพื่อให้แก้ปัญหาแล้วลองใหม่ได้
                LOGGER.exception("ยังนำเข้า %s ไม่สำเร็จ", path.name)
                results.append(ImportResult(path.name, "retry", message=str(exc)))
        return results

    def products(self):
        with closing(self.connect()) as connection:
            return connection.execute("SELECT * FROM products ORDER BY product_id").fetchall()

    def history(self, limit=20):
        with closing(self.connect()) as connection:
            return connection.execute(
                "SELECT * FROM import_history ORDER BY id DESC LIMIT ?", (limit,)
            ).fetchall()

    def get_product(self, product_id: str):
        """อ่านสินค้าตามรหัสเพื่อให้ผู้ใช้ตรวจรายการก่อนยืนยันลบ."""
        with closing(self.connect()) as connection:
            return connection.execute(
                "SELECT * FROM products WHERE product_id=?", (product_id,)
            ).fetchone()

    def delete_product(self, product_id: str, expected=None):
        """ลบเฉพาะรหัสที่ระบุ คืนแถวที่ลบ หรือ None หากไม่พบ."""
        with closing(self.connect()) as connection:
            with connection:
                connection.execute("BEGIN IMMEDIATE")
                product = connection.execute(
                    "SELECT * FROM products WHERE product_id=?", (product_id,)
                ).fetchone()
                if product is None:
                    return None
                if expected is not None and tuple(product) != tuple(expected):
                    raise InvalidData("ข้อมูลสินค้านี้เปลี่ยนไปแล้ว กรุณารีเฟรชและตรวจรายการก่อนลบอีกครั้ง")
                connection.execute("DELETE FROM products WHERE product_id=?", (product_id,))
        # บันทึก log หลัง transaction ยืนยันการลบสำเร็จแล้ว
        LOGGER.info("delete | %s | %s", product["product_id"], product["product_name"])
        return product

    def reduce_quantity(self, product_id: str, amount: int, expected=None):
        """หักจำนวนชิ้นโดยไม่ลบรหัสสินค้า แม้ยอดเหลือศูนย์; คืน None เมื่อไม่พบ."""
        if isinstance(amount, bool) or not isinstance(amount, int) or amount < 1:
            raise InvalidData("จำนวนที่ต้องการลบต้องเป็นจำนวนเต็มอย่างน้อย 1 ชิ้น")
        with closing(self.connect()) as connection:
            with connection:
                connection.execute("BEGIN IMMEDIATE")
                product = connection.execute("SELECT * FROM products WHERE product_id=?", (product_id,)).fetchone()
                if product is None:
                    return None
                if expected is not None and tuple(product) != tuple(expected):
                    raise InvalidData("ยอดสินค้านี้เปลี่ยนไปแล้ว กรุณารีเฟรชและเลือกจำนวนใหม่")
                if amount > product["quantity"]:
                    raise InvalidData(f"ลบได้ไม่เกินยอดคงเหลือ {product['quantity']:,} ชิ้น")
                remaining = product["quantity"] - amount
                connection.execute("UPDATE products SET quantity=?, updated_at=? WHERE product_id=?",
                                   (remaining, now_text(), product_id))
        result = StockReduction(product_id, product["product_name"], amount, product["quantity"], remaining)
        LOGGER.info("reduce | %s | removed=%s | before=%s | after=%s", product_id, amount, result.before, result.after)
        return result

    def export_products(self):
        """ส่งออกข้อมูลปัจจุบันเป็น Excel; คืน (เส้นทาง, จำนวนแถว) หรือ None เมื่อไม่มีสินค้า."""
        rows = self.products()
        if not rows:
            return None
        workbook = Workbook()
        sheet = workbook.active
        sheet.title = "Products"
        sheet.append(HEADERS)
        for row_number, product in enumerate(rows, start=2):
            # กำหนดชนิดข้อความชัดเจน เพื่อรักษาศูนย์นำหน้าและไม่ตีความชื่อเป็นสูตร
            for column, key in enumerate(("product_id", "product_name", "category"), start=1):
                cell = sheet.cell(row=row_number, column=column, value=product[key])
                cell.data_type = "s"
                cell.number_format = "@"
            sheet.cell(row=row_number, column=4, value=Decimal(product["price_satang"]) / 100)
            sheet.cell(row=row_number, column=5, value=product["quantity"])
            sheet.cell(row=row_number, column=4).number_format = "#,##0.00"
            sheet.cell(row=row_number, column=5).number_format = "#,##0"
        for row in sheet.iter_rows():
            for cell in row:
                cell.font = Font(name="Tahoma", size=11)
                cell.alignment = Alignment(vertical="center")
            sheet.row_dimensions[row[0].row].height = 25
        for cell in sheet[1]:
            cell.font = Font(name="Tahoma", size=11, bold=True, color="FFFFFF")
            cell.fill = PatternFill(fill_type="solid", fgColor="243D5B")
            cell.alignment = Alignment(horizontal="center", vertical="center")
        for column, width in {"A": 19, "B": 32, "C": 25, "D": 18, "E": 16}.items():
            sheet.column_dimensions[column].width = width
        sheet.freeze_panes = "A2"
        sheet.auto_filter.ref = sheet.dimensions
        sheet.sheet_view.showGridLines = False

        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        target = self.root / "exports" / f"inventory_{stamp}_{uuid4().hex[:12]}.xlsx"
        temporary = target.with_suffix(".tmp.xlsx")
        try:
            # เขียนไฟล์ชั่วคราวให้เสร็จก่อน จึงเปลี่ยนเป็นชื่อไฟล์ส่งออกจริง
            workbook.save(temporary)
            temporary.replace(target)
        finally:
            workbook.close()
            temporary.unlink(missing_ok=True)
        LOGGER.info("export | %s | %s products", target.name, len(rows))
        return target, len(rows)
