-- ราคาจัดเก็บเป็นจำนวนเต็มหน่วยสตางค์ เช่น 25.50 บาท = 2550
CREATE TABLE IF NOT EXISTS products (
    product_id TEXT PRIMARY KEY NOT NULL,
    product_name TEXT NOT NULL,
    category TEXT NOT NULL,
    price_satang INTEGER NOT NULL CHECK (price_satang >= 0),
    quantity INTEGER NOT NULL CHECK (quantity >= 0),
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS import_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    filename TEXT NOT NULL,
    file_hash TEXT NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('success', 'duplicate', 'error')),
    inserted INTEGER NOT NULL DEFAULT 0,
    updated INTEGER NOT NULL DEFAULT 0,
    unchanged INTEGER NOT NULL DEFAULT 0,
    message TEXT NOT NULL,
    imported_at TEXT NOT NULL
);

-- รุ่นรับสินค้าแบบสะสม: อนุญาตให้นำเนื้อหาเดิมเข้ามาเป็นงานใหม่ได้ทุกครั้ง
-- ลบดัชนีเดิมเท่านั้น ไม่ลบสินค้าและประวัติที่มีอยู่
DROP INDEX IF EXISTS one_success_per_hash;
CREATE INDEX IF NOT EXISTS import_history_hash ON import_history(file_hash);

-- บันทึกงานที่ทำเสร็จใน transaction เดียวกับสินค้า เพื่อกันการบวกซ้ำ
-- เมื่อโปรแกรมปิดหลัง commit แต่ยังย้ายไฟล์ออกจาก processing ไม่สำเร็จ
CREATE TABLE IF NOT EXISTS import_deliveries (
    delivery_id TEXT PRIMARY KEY NOT NULL,
    file_hash TEXT NOT NULL,
    history_id INTEGER NOT NULL REFERENCES import_history(id)
);

CREATE VIEW IF NOT EXISTS inventory_view AS
SELECT product_id, product_name, category,
       price_satang / 100.0 AS price_baht,
       quantity, updated_at
FROM products;
