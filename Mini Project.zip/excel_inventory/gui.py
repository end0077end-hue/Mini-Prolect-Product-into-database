"""หน้าต่างจัดการสินค้า ใช้ฐานข้อมูลเดียวกับ main.py และไม่ต้องติดตั้งเว็บเซิร์ฟเวอร์."""

from __future__ import annotations

import argparse
import logging
from logging.handlers import RotatingFileHandler
import os
from pathlib import Path
import queue
import subprocess
import sys
import threading
import tkinter as tk
from tkinter import filedialog, font, messagebox, simpledialog, ttk

from importer import InventoryImporter


LABELS = {"success": "สำเร็จ", "duplicate": "บันทึกไว้แล้ว", "error": "ข้อมูลผิด", "retry": "รอลองใหม่"}
BG, INK, MUTED, BLUE = "#F3F6FA", "#15283F", "#526479", "#2063B5"


def money(satang):
    return f"{satang // 100:,}.{satang % 100:02d}"


class InventoryApp:
    def __init__(self, root, service, interval=5000):
        self.root, self.service, self.interval = root, service, interval
        self.rows, self.history_rows = [], []
        self.busy = self.auto = self.confirming = self.closed = False
        self.auto_timer = None
        self.messages = queue.Queue()
        self.job_done = None
        self.controls = []
        self.root.title("ระบบจัดการสินค้า | Excel Inventory")
        self.root.geometry("1140x760")
        self.root.minsize(960, 680)
        self.root.configure(bg=BG)
        self.root.protocol("WM_DELETE_WINDOW", self.close)
        self.root.report_callback_exception = self.callback_error
        self.search = tk.StringVar()
        self.status = tk.StringVar(value="กำลังอ่านฐานข้อมูล…")
        self.auto_label = tk.StringVar(value="โหมดอัตโนมัติปิดอยู่")
        self.selection_label = tk.StringVar(value="เลือกสินค้าจากตารางเพื่อลบ")
        self.count_label = tk.StringVar()
        self._style()
        self._build()
        self.search.trace_add("write", lambda *_: self.render_products())
        self.poll_timer = self.root.after(60, self.poll)
        self.refresh()

    def _style(self):
        families = {name.casefold(): name for name in font.families(self.root)}
        family = families.get("tahoma", families.get("sarabun", font.nametofont("TkDefaultFont").actual("family")))
        self.family = family
        for name in font.names(self.root):
            if name != "TkFixedFont":
                font.nametofont(name, root=self.root).configure(family=family)
        style = ttk.Style(self.root)
        style.theme_use("clam")
        style.configure(".", font=(family, 11), background=BG, foreground=INK)
        style.configure("TFrame", background=BG)
        style.configure("TLabel", background=BG, foreground=INK)
        style.configure("TButton", padding=(12, 8), borderwidth=1)
        style.configure("Primary.TButton", background=BLUE, foreground="white")
        style.map("Primary.TButton", background=[("disabled", "#CDD7E5"), ("active", "#194D8D")],
                  foreground=[("disabled", "#6B7789")])
        style.configure("Danger.TButton", background="#B63342", foreground="white")
        style.map("Danger.TButton", background=[("disabled", "#E5E9EF"), ("active", "#922635")],
                  foreground=[("disabled", "#7C8897")])
        style.configure("Treeview", background="white", fieldbackground="white", rowheight=35,
                        borderwidth=0, font=(family, 11))
        style.configure("Treeview.Heading", background="#E9EFF6", foreground=INK,
                        font=(family, 11, "bold"), padding=(8, 9))
        style.map("Treeview", background=[("selected", "#D7E8FC")], foreground=[("selected", INK)])
        style.configure("TNotebook", borderwidth=0, background=BG)
        style.configure("TNotebook.Tab", padding=(18, 9))
        style.map("TNotebook.Tab", background=[("selected", "white")], foreground=[("selected", BLUE)])

    def _button(self, parent, text, command, style="TButton"):
        button = ttk.Button(parent, text=text, command=command, style=style)
        self.controls.append(button)
        return button

    def _build(self):
        header = tk.Frame(self.root, bg="#163B64", padx=24, pady=10)
        header.pack(fill="x")
        tk.Label(header, text="คลังสินค้า", font=(self.family, 20, "bold"), bg="#163B64", fg="white").pack(side="left")
        tk.Label(header, text="นำเข้า Excel  •  บวกสต็อกเพิ่มทุกครั้ง", font=(self.family, 12),
                 bg="#163B64", fg="#D7E8FC").pack(side="left", padx=20)
        tk.Label(header, textvariable=self.auto_label, font=(self.family, 9),
                 bg="#163B64", fg="#D7E8FC").pack(side="right")
        body = ttk.Frame(self.root, padding=(22, 10, 22, 8))
        body.pack(fill="both", expand=True)
        metrics = ttk.Frame(body)
        metrics.pack(fill="x", pady=(0, 14))
        self.metrics = []
        for index, label in enumerate(("สินค้าทั้งหมด (รหัส)", "คงเหลือรวม (ชิ้น)", "มูลค่ารวม (บาท)")):
            card = tk.Frame(metrics, bg="white", padx=14, pady=6, highlightbackground="#DEE5EF", highlightthickness=1)
            card.grid(row=0, column=index, sticky="nsew", padx=(0 if index == 0 else 10, 0))
            metrics.columnconfigure(index, weight=1)
            tk.Label(card, text=label, font=(self.family, 10), bg="white", fg=MUTED).pack(side="left")
            var = tk.StringVar(value="—")
            self.metrics.append(var)
            tk.Label(card, textvariable=var, font=(self.family, 18, "bold"), bg="white", fg=INK).pack(side="right", padx=(10, 0))
        actions = ttk.Frame(body)
        actions.pack(fill="x", pady=(0, 8))
        self._button(actions, "เลือก Excel เพิ่มสต็อก", self.choose_excel, "Primary.TButton").pack(side="left", padx=(0, 8))
        self._button(actions, "นำเข้าจาก inbox", self.import_inbox).pack(side="left", padx=(0, 8))
        self.auto_button = self._button(actions, "เริ่มอัตโนมัติ", self.toggle_auto)
        self.auto_button.pack(side="left", padx=(0, 8))
        self._button(actions, "ส่งออก Excel", self.export).pack(side="left", padx=(0, 8))
        self._button(actions, "รีเฟรช", self.refresh).pack(side="right")

        self.tabs = ttk.Notebook(body)
        self.tabs.pack(fill="both", expand=True)
        products_tab, history_tab = ttk.Frame(self.tabs, padding=12), ttk.Frame(self.tabs, padding=12)
        self.tabs.add(products_tab, text="รายการสินค้า")
        self.tabs.add(history_tab, text="ประวัติการนำเข้า")
        searchbar = ttk.Frame(products_tab)
        searchbar.pack(fill="x", pady=(0, 10))
        ttk.Label(searchbar, text="ค้นหา").pack(side="left", padx=(0, 8))
        self.search_entry = ttk.Entry(searchbar, textvariable=self.search, width=37, font=(self.family, 11))
        self.search_entry.pack(side="left", ipady=4)
        ttk.Button(searchbar, text="ล้างคำค้น", command=lambda: self.search.set("")).pack(side="left", padx=8)
        ttk.Label(searchbar, text="รหัส • ชื่อ • หมวดหมู่", foreground=MUTED).pack(side="left")
        columns = (("id", "รหัสสินค้า", 115), ("name", "ชื่อสินค้า", 245), ("category", "หมวดหมู่", 140),
                   ("price", "ราคา (บาท)", 115), ("quantity", "คงเหลือ", 90), ("updated", "อัปเดตล่าสุด", 180))
        self.tree = self._table(products_tab, columns)
        for column in ("price", "quantity"):
            self.tree.column(column, anchor="e")
        self.tree.bind("<<TreeviewSelect>>", self.selection_changed)
        below = ttk.Frame(products_tab)
        below.pack(fill="x", pady=(10, 0))
        ttk.Label(below, textvariable=self.count_label, foreground=MUTED).pack(side="left")
        self.delete_button = self._button(below, "ลบรหัสสินค้า", self.delete_selected, "Danger.TButton")
        self.delete_button.pack(side="right")
        self.reduce_button = self._button(below, "ลบตามจำนวน", self.reduce_selected, "Primary.TButton")
        self.reduce_button.pack(side="right", padx=(8, 8))
        ttk.Label(below, textvariable=self.selection_label, foreground=MUTED, wraplength=240).pack(side="left", padx=10)
        below.pack_configure(side="bottom", before=self.tree.master)

        ttk.Label(history_tab, text="การนำเข้า 100 ครั้งล่าสุด", foreground=MUTED).pack(anchor="w", pady=(0, 10))
        self.history_tree = self._table(history_tab, (("time", "เวลา", 175), ("filename", "ชื่อไฟล์", 250),
                                                    ("status", "สถานะ", 95), ("message", "ผลการนำเข้า", 420)))
        self.history_tree.bind("<Double-1>", self.show_history_detail)
        ttk.Label(history_tab, text="ดับเบิลคลิกรายการเพื่ออ่านข้อความทั้งหมด", foreground=MUTED).pack(
            side="bottom", before=self.history_tree.master, anchor="w", pady=(8, 0))
        footer = ttk.Frame(body)
        footer.pack(fill="x", pady=(8, 0))
        footer.columnconfigure(0, weight=1)
        ttk.Label(footer, textvariable=self.status, wraplength=540).grid(row=0, column=0, sticky="w")
        self.progress = ttk.Progressbar(footer, mode="indeterminate", length=70)
        self.progress.grid(row=0, column=1, padx=10, sticky="e")
        ttk.Label(footer, text=f"ฐานข้อมูล: {self.service.db_path}", foreground=MUTED,
                  font=(self.family, 9), wraplength=680).grid(row=1, column=0, columnspan=2, sticky="w")
        folders = ttk.Frame(footer)
        folders.grid(row=0, column=2, rowspan=2, sticky="e")
        ttk.Button(folders, text="เปิด inbox", command=lambda: self.open_folder("inbox")).pack(side="right", padx=(6, 0))
        ttk.Button(folders, text="เปิด exports", command=lambda: self.open_folder("exports")).pack(side="right")
        # กันพื้นที่สถานะและปุ่มด้านล่างก่อนให้ตารางขยาย เพื่อไม่ให้ถูกตัดเมื่อย่อหน้าต่าง
        footer.pack_configure(side="bottom", before=self.tabs)

    def _table(self, parent, columns):
        frame = ttk.Frame(parent)
        frame.pack(fill="both", expand=True)
        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)
        tree = ttk.Treeview(frame, columns=[c[0] for c in columns], show="headings", selectmode="browse", height=6)
        for key, label, width in columns:
            tree.heading(key, text=label)
            tree.column(key, width=width, minwidth=70, stretch=key in ("name", "message", "filename"))
        tree.grid(row=0, column=0, sticky="nsew")
        vertical = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
        horizontal = ttk.Scrollbar(frame, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=vertical.set, xscrollcommand=horizontal.set)
        vertical.grid(row=0, column=1, sticky="ns")
        horizontal.grid(row=1, column=0, sticky="ew")
        tree.tag_configure("even", background="white")
        tree.tag_configure("odd", background="#F4F7FB")
        return tree

    def set_busy(self, value):
        self.busy = value
        for button in self.controls:
            button.state(["disabled"] if value else ["!disabled"])
        self.progress.start(12) if value else self.progress.stop()
        self.selection_changed()

    def start_job(self, work, done, description):
        if self.busy or self.closed:
            return
        self.job_done = done
        self.set_busy(True)
        self.status.set(description)

        def worker():
            try:
                result = work()
            except Exception as exc:
                logging.exception("UI operation failed")
                self.messages.put((False, exc, None, None))
                return
            try:
                snapshot = self.service.products(), self.service.history(100)
                refresh_error = None
            except Exception as exc:
                logging.exception("UI refresh failed after operation")
                snapshot, refresh_error = None, str(exc)
            self.messages.put((True, result, snapshot, refresh_error))

        # ฐานข้อมูลและ Excel ทำงานใน thread นี้; แตะ widget เฉพาะ main thread เท่านั้น
        threading.Thread(target=worker, name="inventory-worker", daemon=False).start()

    def poll(self):
        try:
            success, result, snapshot, refresh_error = self.messages.get_nowait()
        except queue.Empty:
            pass
        else:
            if snapshot is not None:
                self.rows, self.history_rows = snapshot
                self.render_products()
                self.render_history()
            self.set_busy(False)
            if success:
                self.job_done(result)
                if refresh_error:
                    messagebox.showwarning("ทำงานสำเร็จ แต่แสดงผลล่าสุดไม่ได้",
                                           f"กดรีเฟรชเพื่ออ่านข้อมูลอีกครั้ง\n\n{refresh_error}", parent=self.root)
            else:
                # หยุดการตรวจอัตโนมัติเมื่อระบบขัดข้อง เพื่อไม่แสดงข้อผิดพลาดวนซ้ำ
                self.stop_auto()
                self.status.set(f"ทำรายการไม่สำเร็จ: {result}")
                messagebox.showerror("ทำรายการไม่สำเร็จ", str(result), parent=self.root)
            self.schedule_auto()
        if not self.closed:
            self.poll_timer = self.root.after(60, self.poll)

    def render_products(self):
        selected = self.tree.selection()
        selected_id = selected[0] if selected else None
        query = self.search.get().strip().casefold()
        visible = [row for row in self.rows if not query or any(query in str(row[key]).casefold()
                   for key in ("product_id", "product_name", "category"))]
        self.tree.delete(*self.tree.get_children())
        for index, row in enumerate(visible):
            self.tree.insert("", "end", iid=row["product_id"], values=(row["product_id"], row["product_name"],
                             row["category"], money(row["price_satang"]), f"{row['quantity']:,}",
                             row["updated_at"][:19].replace("T", " ")), tags=("odd" if index % 2 else "even",))
        if selected_id and self.tree.exists(selected_id):
            self.tree.selection_set(selected_id)
        self.metrics[0].set(f"{len(self.rows):,}")
        self.metrics[1].set(f"{sum(row['quantity'] for row in self.rows):,}")
        self.metrics[2].set(money(sum(row["price_satang"] * row["quantity"] for row in self.rows)))
        text = f"แสดง {len(visible):,} จาก {len(self.rows):,} รหัสสินค้า"
        if not self.rows:
            text = "ยังไม่มีสินค้า — กดเลือก Excel เพื่อนำเข้า"
        elif not visible:
            text = "ไม่พบสินค้าที่ตรงกับคำค้น"
        self.count_label.set(text)
        self.selection_changed()

    def render_history(self):
        self.history_tree.delete(*self.history_tree.get_children())
        for index, row in enumerate(self.history_rows):
            self.history_tree.insert("", "end", iid=str(row["id"]), values=(row["imported_at"][:19].replace("T", " "),
                                     row["filename"], LABELS.get(row["status"], row["status"]), row["message"]),
                                     tags=("odd" if index % 2 else "even",))

    def selection_changed(self, _event=None):
        selected = self.tree.selection()
        row = None
        if selected:
            row = next((row for row in self.rows if row["product_id"] == selected[0]), None)
            if row:
                name = row['product_name'][:20] + ("…" if len(row['product_name']) > 20 else "")
                self.selection_label.set(f"เลือก: {row['product_id']} • {name}")
        else:
            self.selection_label.set("เลือกสินค้าจากตารางเพื่อลบ")
        self.delete_button.state(["!disabled"] if selected and not self.busy else ["disabled"])
        self.reduce_button.state(["!disabled"] if row and row["quantity"] > 0 and not self.busy else ["disabled"])

    def refresh(self):
        self.start_job(lambda: None, lambda _: self.status.set("แสดงข้อมูลล่าสุดแล้ว"), "กำลังอ่านฐานข้อมูล…")

    def choose_excel(self):
        if self.busy:
            return
        self.confirming = True
        try:
            paths = filedialog.askopenfilenames(title="เลือก Excel เพิ่มสต็อก (เลือกได้หลายไฟล์ / ไฟล์เดิมซ้ำได้)",
                                                filetypes=[("Excel workbook", "*.xlsx")], parent=self.root)
        finally:
            self.confirming = False
        if paths:
            self.start_job(lambda: self.service.import_selected_files(paths),
                           lambda results: self.import_done(results, True), f"กำลังนำเข้า {len(paths)} ไฟล์และบวกสต็อก…")

    def import_inbox(self):
        self.start_job(self.service.scan_once, lambda results: self.import_done(results, True), "กำลังนำเข้าจาก inbox…")

    def import_done(self, results, notify=False):
        if not results:
            self.status.set("ไม่พบไฟล์ใหม่ที่พร้อมนำเข้า" if notify else "กำลังตรวจ inbox อัตโนมัติ — รอไฟล์ใหม่")
            return
        lines = [f"[{LABELS[result.status]}] {result.filename}\n{result.message}" for result in results]
        summary = f"ประมวลผล {len(results)} ไฟล์ | สำเร็จ {sum(r.status == 'success' for r in results)} | งานเดิมที่บันทึกแล้ว {sum(r.status == 'duplicate' for r in results)} | มีปัญหา {sum(r.status in ('error', 'retry') for r in results)}"
        self.status.set(summary)
        if notify:
            dialog = messagebox.showwarning if any(r.status in ("error", "retry") for r in results) else messagebox.showinfo
            details = "\n\n".join(lines[:8])
            if len(lines) > 8:
                details += "\n\nดูรายละเอียดไฟล์ที่เหลือในแท็บประวัติการนำเข้า"
            dialog("ผลการนำเข้า", details, parent=self.root)

    def toggle_auto(self):
        if self.auto:
            self.stop_auto()
            self.status.set("หยุดโหมดอัตโนมัติแล้ว")
        else:
            self.auto = True
            self.auto_button.configure(text="หยุดอัตโนมัติ")
            self.auto_label.set(f"เปิดอัตโนมัติ • ตรวจ inbox ทุก {self.interval / 1000:g} วินาที")
            self.auto_tick()

    def stop_auto(self):
        self.auto = False
        if self.auto_timer is not None:
            self.root.after_cancel(self.auto_timer)
            self.auto_timer = None
        self.auto_button.configure(text="เริ่มอัตโนมัติ")
        self.auto_label.set("โหมดอัตโนมัติปิดอยู่")

    def schedule_auto(self):
        if self.auto and self.auto_timer is None and not self.closed:
            self.auto_timer = self.root.after(self.interval, self.auto_tick)

    def auto_tick(self):
        self.auto_timer = None
        if not self.auto or self.closed:
            return
        if self.busy or self.confirming:
            self.schedule_auto()
        else:
            self.start_job(lambda: self.service.scan_once(require_stable=True), self.import_done, "กำลังตรวจ inbox…")

    def reduce_selected(self):
        selected = self.tree.selection()
        if self.busy or not selected:
            return
        product = next((row for row in self.rows if row["product_id"] == selected[0]), None)
        if product is None or product["quantity"] < 1:
            return
        self.confirming = True
        confirmed = False
        try:
            amount = simpledialog.askinteger(
                "ลบสินค้าตามจำนวน",
                f"{product['product_id']} • {product['product_name']}\n"
                f"คงเหลือ {product['quantity']:,} ชิ้น\n\nระบุจำนวนชิ้นที่ต้องการลบ:",
                minvalue=1, maxvalue=product["quantity"], initialvalue=1, parent=self.root,
            )
            if amount is not None:
                confirmed = messagebox.askyesno(
                    "ยืนยันลบตามจำนวน",
                    f"{product['product_id']} • {product['product_name']}\n\n"
                    f"คงเหลือเดิม: {product['quantity']:,} ชิ้น\nลบออก: {amount:,} ชิ้น\n"
                    f"คงเหลือหลังลบ: {product['quantity'] - amount:,} ชิ้น\n\n"
                    "รหัสสินค้ายังคงอยู่ แม้จำนวนเหลือ 0",
                    parent=self.root, icon="question", default="no",
                )
        finally:
            self.confirming = False
        if confirmed:
            self.start_job(lambda: self.service.reduce_quantity(product["product_id"], amount, expected=tuple(product)),
                           self.reduce_done, "กำลังลบสินค้าตามจำนวน…")
        else:
            self.status.set("ยกเลิกการลบตามจำนวนแล้ว")

    def reduce_done(self, result):
        if result is None:
            self.status.set("ไม่พบสินค้านี้แล้ว แสดงข้อมูลล่าสุดให้แล้ว")
        else:
            self.status.set(f"{result.product_id} • ลบ {result.removed:,} ชิ้น | เดิม {result.before:,} → เหลือ {result.after:,} ชิ้น")

    def delete_selected(self):
        selected = self.tree.selection()
        if self.busy or not selected:
            return
        product = next((row for row in self.rows if row["product_id"] == selected[0]), None)
        if product is None:
            return
        self.confirming = True
        try:
            confirmed = messagebox.askyesno("ยืนยันลบรหัสสินค้าทั้งรายการ",
                f"ต้องการลบรหัสนี้พร้อมจำนวนคงเหลือทั้งหมดออกจากฐานข้อมูลหรือไม่?\n\nรหัส: {product['product_id']}\nชื่อ: {product['product_name']}\nคงเหลือ: {product['quantity']:,} ชิ้น\n\nหากต้องการหักเพียงบางส่วน ให้ยกเลิกแล้วกด ลบตามจำนวน",
                parent=self.root, icon="warning", default="no")
        finally:
            self.confirming = False
        if confirmed:
            self.start_job(lambda: self.service.delete_product(product["product_id"], expected=tuple(product)),
                           self.delete_done, "กำลังลบสินค้าที่เลือก…")
        else:
            self.status.set("ยกเลิกการลบแล้ว")

    def delete_done(self, product):
        if product is None:
            self.status.set("ไม่พบสินค้านี้แล้ว แสดงข้อมูลล่าสุดให้แล้ว")
            messagebox.showinfo("ไม่พบสินค้า", "สินค้านี้ถูกลบไปแล้ว", parent=self.root)
        else:
            self.status.set(f"ลบ {product['product_id']} — {product['product_name']} สำเร็จ")

    def export(self):
        self.start_job(self.service.export_products, self.export_done, "กำลังส่งออกสินค้าทั้งหมดเป็น Excel…")

    def export_done(self, result):
        if result is None:
            self.status.set("ยังไม่มีสินค้าให้ส่งออก")
            messagebox.showinfo("ยังไม่มีข้อมูล", "กรุณานำเข้าสินค้าก่อนส่งออก", parent=self.root)
        else:
            path, count = result
            self.status.set(f"ส่งออกแล้ว {count:,} รหัสสินค้า • {path.name}")
            messagebox.showinfo("ส่งออกสำเร็จ", f"ส่งออก {count:,} รหัสสินค้า\n\n{path}\n\nกดปุ่มเปิด exports เพื่อเปิดโฟลเดอร์", parent=self.root)

    def show_history_detail(self, _event=None):
        selected = self.history_tree.selection()
        if selected:
            row = next(row for row in self.history_rows if str(row["id"]) == selected[0])
            messagebox.showinfo("รายละเอียดการนำเข้า", f"{row['filename']}\n{row['imported_at']}\n\n{row['message']}", parent=self.root)

    def open_folder(self, name):
        path = str(self.service.root / name)
        try:
            if sys.platform == "win32":
                os.startfile(path)
            else:
                subprocess.Popen(["open" if sys.platform == "darwin" else "xdg-open", path])
        except OSError as exc:
            messagebox.showerror("เปิดโฟลเดอร์ไม่ได้", f"{path}\n\n{exc}", parent=self.root)

    def callback_error(self, exc_type, exc_value, traceback):
        logging.error("UI callback failed", exc_info=(exc_type, exc_value, traceback))
        messagebox.showerror("เกิดข้อผิดพลาด", str(exc_value), parent=self.root)

    def close(self):
        if self.busy:
            messagebox.showinfo("กำลังทำงาน", "กรุณารอให้รายการปัจจุบันเสร็จก่อนปิดโปรแกรม", parent=self.root)
            return
        self.stop_auto()
        self.closed = True
        self.root.after_cancel(self.poll_timer)
        self.root.destroy()


def main():
    parser = argparse.ArgumentParser(description="หน้าต่างจัดการสินค้า Excel และ SQLite")
    parser.add_argument("--data-dir", type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    root = tk.Tk()
    root.withdraw()
    try:
        service = InventoryImporter(args.data_dir)
        handler = RotatingFileHandler(service.root / "logs" / "system.log", maxBytes=1_000_000,
                                      backupCount=2, encoding="utf-8")
        logging.basicConfig(level=logging.INFO, handlers=[handler], format="%(asctime)s %(levelname)s %(message)s")
        InventoryApp(root, service)
    except Exception as exc:
        logging.exception("UI startup failed")
        messagebox.showerror("เปิดระบบไม่สำเร็จ", str(exc), parent=root)
        root.destroy()
        return 1
    root.deiconify()
    root.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
