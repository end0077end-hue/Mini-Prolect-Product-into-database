@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    echo Run setup_windows.bat first.
    pause
    exit /b 1
)
".venv\Scripts\python.exe" -c "import tkinter, openpyxl" >nul 2>nul
if errorlevel 1 (
    echo Python needs tkinter and openpyxl.
    echo Install Python with Tcl/Tk support, then run setup_windows.bat again.
    pause
    exit /b 1
)
".venv\Scripts\python.exe" gui.py
if errorlevel 1 pause
