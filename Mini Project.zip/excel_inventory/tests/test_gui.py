"""ทดสอบ widget จริงและฐานข้อมูลชั่วคราว; ต้องมีหน้าจอหรือ Xvfb."""

from pathlib import Path
from contextlib import closing
import shutil
import tempfile
import threading
import time
import tkinter as tk
import unittest
from unittest.mock import patch

from gui import InventoryApp
from importer import InventoryImporter, read_products


PROJECT = Path(__file__).resolve().parents[1]
EXAMPLE = PROJECT / "examples" / "01_products.xlsx"


class GuiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        try:
            root = tk.Tk()
            root.destroy()
        except tk.TclError as exc:
            raise unittest.SkipTest(f"GUI tests need a display: {exc}")

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.data = Path(self.tmp.name) / "project"
        self.service = InventoryImporter(self.data)
        self.window = tk.Tk()
        self.window.withdraw()
        self.info = self.mock_dialog("showinfo")
        self.warning = self.mock_dialog("showwarning")
        self.error = self.mock_dialog("showerror")
        self.confirm = self.mock_dialog("askyesno", return_value=False)
        quantity_patcher = patch("gui.simpledialog.askinteger", return_value=None)
        self.addCleanup(quantity_patcher.stop)
        self.quantity = quantity_patcher.start()
        self.app = InventoryApp(self.window, self.service, interval=40)
        self.pump_until(lambda: not self.app.busy)

    def mock_dialog(self, name, **kwargs):
        patcher = patch("gui.messagebox." + name, **kwargs)
        self.addCleanup(patcher.stop)
        return patcher.start()

    def tearDown(self):
        self.app.stop_auto()
        self.pump_until(lambda: not self.app.busy)
        self.app.close()
        self.tmp.cleanup()

    def pump_until(self, predicate, timeout=8):
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            self.window.update()
            if predicate():
                return
            time.sleep(0.01)
        self.fail("UI operation timed out")

    def initial(self):
        self.service.import_bytes(EXAMPLE.name, EXAMPLE.read_bytes())
        self.app.refresh()
        self.pump_until(lambda: not self.app.busy)

    def select(self, product_id):
        self.app.tree.selection_set(product_id)
        self.window.update()

    def test_real_table_search_and_totals(self):
        self.initial()
        self.assertEqual(len(self.app.tree.get_children()), 8)
        self.assertEqual(self.app.metrics[0].get(), "8")
        self.assertEqual(self.app.metrics[2].get(), "8,440.00")
        self.app.search.set("ปากกา")
        self.assertEqual(self.app.tree.get_children(), ("P001",))
        self.app.search.set("p003")
        self.assertEqual(self.app.tree.get_children(), ("P003",))
        self.app.search.set("ไม่มีรายการนี้")
        self.assertEqual(self.app.tree.get_children(), ())
        self.assertTrue(self.app.delete_button.instate(["disabled"]))

    def test_delete_button_requires_selection_and_confirmation_then_persists(self):
        self.initial()
        self.assertTrue(self.app.delete_button.instate(["disabled"]))
        self.select("P001")
        self.app.delete_button.invoke()
        self.assertIn("P001", self.confirm.call_args.args[1])
        self.assertIn("ปากกาลูกลื่น", self.confirm.call_args.args[1])
        self.assertEqual(len(self.service.products()), 8)
        self.confirm.return_value = True
        self.app.delete_button.invoke()
        self.pump_until(lambda: not self.app.busy)
        self.assertIsNone(InventoryImporter(self.data).get_product("P001"))
        self.assertEqual(len(self.app.tree.get_children()), 7)
        self.assertEqual(self.app.metrics[0].get(), "7")
        self.assertTrue(self.app.delete_button.instate(["disabled"]))
        self.assertIsNotNone(self.service.get_product("P002"))
        self.assertEqual(len(self.service.history()), 1)

    def test_stale_confirmation_never_deletes_changed_product(self):
        self.initial()
        self.select("P001")
        with closing(self.service.connect()) as connection:
            with connection:
                connection.execute("UPDATE products SET quantity=999 WHERE product_id='P001'")
        self.confirm.return_value = True
        self.app.delete_button.invoke()
        self.pump_until(lambda: not self.app.busy)
        self.error.assert_called_once()
        self.assertEqual(self.service.get_product("P001")["quantity"], 999)
        self.assertEqual(len(self.service.products()), 8)

    def test_file_picker_preserves_original_and_populates_table(self):
        source = Path(self.tmp.name) / "รายการสินค้า.xlsx"
        shutil.copy2(EXAMPLE, source)
        original = source.read_bytes()
        with patch("gui.filedialog.askopenfilenames", return_value=(str(source),)):
            self.app.choose_excel()
        self.pump_until(lambda: not self.app.busy)
        self.assertEqual(source.read_bytes(), original)
        self.assertEqual(len(self.app.tree.get_children()), 8)
        self.assertEqual(len(list((self.data / "processed").glob("*.xlsx"))), 1)
        self.assertEqual(len(list((self.data / "inbox").glob("*.xlsx"))), 0)

    def test_bad_file_shows_error_result_without_partial_products(self):
        source = PROJECT / "examples" / "03_invalid.xlsx"
        with patch("gui.filedialog.askopenfilenames", return_value=(str(source),)):
            self.app.choose_excel()
        self.pump_until(lambda: not self.app.busy)
        self.assertEqual(self.service.products(), [])
        self.assertEqual(self.app.tree.get_children(), ())
        self.assertEqual(len(list((self.data / "failed").glob("*.error.txt"))), 1)
        self.warning.assert_called_once()
        self.assertTrue(source.exists())

    def test_multiple_file_picker_adds_both_then_allows_identical_upload_again(self):
        second = PROJECT / "examples" / "02_update.xlsx"
        with patch("gui.filedialog.askopenfilenames", return_value=(str(EXAMPLE), str(second))):
            self.app.choose_excel()
        self.pump_until(lambda: not self.app.busy)
        self.assertEqual(self.service.get_product("P001")["quantity"], 220)
        self.assertEqual(len(self.app.tree.get_children()), 9)
        self.assertEqual(self.app.metrics[2].get(), "11,950.00")
        with patch("gui.filedialog.askopenfilenames", return_value=(str(EXAMPLE),)):
            self.app.choose_excel()
        self.pump_until(lambda: not self.app.busy)
        self.assertEqual(self.service.get_product("P001")["quantity"], 320)
        self.assertEqual(len(self.app.history_tree.get_children()), 3)

    def test_quantity_button_cancel_both_dialogs_then_subtract_selected_amount(self):
        self.initial()
        self.assertTrue(self.app.reduce_button.instate(["disabled"]))
        self.select("P001")
        self.app.reduce_button.invoke()  # ยกเลิกช่องจำนวน
        self.confirm.assert_not_called()
        self.assertEqual(self.service.get_product("P001")["quantity"], 100)
        self.quantity.return_value = 5
        self.app.reduce_button.invoke()  # ยกเลิกหน้าต่างยืนยัน
        self.assertEqual(self.quantity.call_args.kwargs["minvalue"], 1)
        self.assertEqual(self.quantity.call_args.kwargs["maxvalue"], 100)
        self.assertIn("95", self.confirm.call_args.args[1])
        self.assertEqual(self.service.get_product("P001")["quantity"], 100)
        self.confirm.return_value = True
        self.app.reduce_button.invoke()
        self.pump_until(lambda: not self.app.busy)
        self.assertEqual(self.service.get_product("P001")["quantity"], 95)
        self.assertEqual(str(self.app.tree.item("P001", "values")[4]), "95")
        self.assertEqual(self.app.metrics[1].get(), "440")
        self.assertEqual(self.service.get_product("P002")["quantity"], 80)

    def test_reducing_to_zero_keeps_row_and_disables_quantity_button(self):
        self.initial()
        self.select("P001")
        self.quantity.return_value = 100
        self.confirm.return_value = True
        self.app.reduce_button.invoke()
        self.pump_until(lambda: not self.app.busy)
        self.assertTrue(self.app.tree.exists("P001"))
        self.assertEqual(self.service.get_product("P001")["quantity"], 0)
        self.assertTrue(self.app.reduce_button.instate(["disabled"]))
        self.assertFalse(self.app.delete_button.instate(["disabled"]))

    def test_stale_quantity_confirmation_preserves_changed_stock(self):
        self.initial()
        self.select("P001")
        self.service.reduce_quantity("P001", 90)
        self.quantity.return_value = 5
        self.confirm.return_value = True
        with self.assertLogs(level="ERROR"):
            self.app.reduce_button.invoke()
            self.pump_until(lambda: not self.app.busy)
        self.error.assert_called_once()
        self.assertEqual(self.service.get_product("P001")["quantity"], 10)

    def test_export_button_outputs_current_products_without_changing_database(self):
        self.initial()
        before = [tuple(r) for r in self.service.products()]
        self.app.export()
        self.pump_until(lambda: not self.app.busy)
        files = list((self.data / "exports").glob("*.xlsx"))
        self.assertEqual(len(files), 1)
        self.assertEqual(read_products(files[0].read_bytes()), [r[:5] for r in before])
        self.assertEqual([tuple(r) for r in self.service.products()], before)

    def test_auto_watch_imports_and_can_be_stopped(self):
        shutil.copy2(EXAMPLE, self.data / "inbox" / "auto.xlsx")
        self.app.toggle_auto()
        self.pump_until(lambda: len(self.app.tree.get_children()) == 8 and not self.app.busy)
        self.app.toggle_auto()
        self.assertFalse(self.app.auto)
        self.assertIsNone(self.app.auto_timer)
        self.assertFalse((self.data / "inbox" / "auto.xlsx").exists())

    def test_busy_ui_keeps_event_loop_responsive_and_waits_before_closing(self):
        release = threading.Event()
        self.addCleanup(release.set)
        self.app.start_job(lambda: release.wait(3), lambda _: None, "test")
        self.window.update()
        self.assertTrue(self.app.busy)
        self.assertTrue(self.app.delete_button.instate(["disabled"]))
        self.app.close()
        self.assertFalse(self.app.closed)
        self.info.assert_called_once()
        release.set()
        self.pump_until(lambda: not self.app.busy)


if __name__ == "__main__":
    unittest.main(verbosity=2)
