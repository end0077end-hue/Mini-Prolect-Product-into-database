"""ทดสอบด้วยไฟล์ Excel จริงและฐานข้อมูลชั่วคราว ไม่กระทบข้อมูลผู้ใช้."""

from contextlib import closing
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import shutil
import sqlite3
import tempfile
import unittest
from unittest.mock import patch

from importer import InventoryImporter, MAX_STOCK


PROJECT = Path(__file__).resolve().parents[1]


class ImporterTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.service = InventoryImporter(self.root)

    def load(self, name):
        return (PROJECT / "examples" / name).read_bytes()

    def fixture(self, name):
        return (PROJECT / "tests" / "fixtures" / name).read_bytes()

    def initial(self):
        return self.service.import_bytes("01_products.xlsx", self.load("01_products.xlsx"))

    def test_initial_import_and_thai_text(self):
        result = self.initial()
        self.assertEqual((result.status, result.inserted), ("success", 8))
        rows = self.service.products()
        self.assertEqual(rows[0]["product_name"], "ปากกาลูกลื่น")
        self.assertEqual(sum(row["price_satang"] * row["quantity"] for row in rows), 844000)
        self.assertEqual(len(self.service.history()), 1)

    def test_same_name_new_content_adds_quantity_and_updates_latest_price(self):
        self.initial()
        result = self.service.import_bytes("01_products.xlsx", self.load("02_update.xlsx"))
        self.assertEqual((result.inserted, result.updated), (1, 2))
        rows = {row["product_id"]: row for row in self.service.products()}
        self.assertEqual(len(rows), 9)
        self.assertEqual(rows["P001"]["quantity"], 220)
        self.assertEqual(rows["P001"]["price_satang"], 1300)
        self.assertEqual(rows["P003"]["quantity"], 110)
        self.assertEqual(rows["P002"]["quantity"], 80)
        self.assertEqual(sum(row["price_satang"] * row["quantity"] for row in rows.values()), 1195000)

    def test_repeated_identical_file_adds_stock_even_after_restart(self):
        self.initial()
        self.service.import_bytes("update.xlsx", self.load("02_update.xlsx"))
        reopened = InventoryImporter(self.root)
        result = reopened.import_bytes("renamed.xlsx", self.load("01_products.xlsx"))
        self.assertEqual(result.status, "success")
        self.assertEqual(reopened.products()[0]["quantity"], 320)
        self.assertEqual(reopened.products()[0]["price_satang"], 1250)
        self.assertEqual(len(reopened.products()), 9)
        self.assertEqual(len(reopened.history()), 3)

    def test_invalid_later_row_does_not_import_valid_earlier_row(self):
        self.initial()
        before = [tuple(row) for row in self.service.products()]
        result = self.service.import_bytes("bad.xlsx", self.load("03_invalid.xlsx"))
        self.assertEqual(result.status, "error")
        self.assertIn("แถว 3", result.message)
        self.assertEqual([tuple(row) for row in self.service.products()], before)
        self.assertEqual(self.service.history()[0]["status"], "error")

    def test_formulas_duplicate_ids_and_corrupt_files_are_rejected(self):
        cases = [("duplicate_id.xlsx", "ซ้ำ"), ("formula.xlsx", "สูตร")]
        for filename, text in cases:
            with self.subTest(filename=filename):
                result = self.service.import_bytes(filename, self.fixture(filename))
                self.assertEqual(result.status, "error")
                self.assertIn(text, result.message)
        result = self.service.import_bytes("broken.xlsx", b"not an xlsx file")
        self.assertEqual(result.status, "error")
        self.assertEqual(len(self.service.products()), 0)

    def test_leading_zero_id_zero_quantity_and_exact_satang(self):
        result = self.service.import_bytes("zero.xlsx", self.fixture("leading_zero.xlsx"))
        self.assertEqual(result.status, "success")
        product = self.service.products()[0]
        self.assertEqual(product["product_id"], "001")
        self.assertEqual(product["quantity"], 0)
        self.assertEqual(product["price_satang"], 10)

    def test_scan_waits_for_stability_and_ignores_office_temporary_files(self):
        inbox = self.root / "inbox"
        shutil.copyfile(PROJECT / "examples" / "01_products.xlsx", inbox / "FIRST.XLSX")
        (inbox / "~$FIRST.xlsx").write_bytes(b"office lock")
        self.assertEqual(self.service.scan_once(require_stable=True), [])
        self.assertEqual(len(self.service.products()), 0)
        results = self.service.scan_once(require_stable=True)
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].status, "success")
        self.assertTrue(Path(results[0].archive).is_file())
        self.assertFalse((inbox / "FIRST.XLSX").exists())
        self.assertTrue((inbox / "~$FIRST.xlsx").exists())
        self.assertEqual(self.service.scan_once(require_stable=True), [])

    def test_failed_file_has_readable_error_report(self):
        source = self.root / "inbox" / "bad.xlsx"
        source.write_bytes(self.load("03_invalid.xlsx"))
        result = self.service.scan_once()[0]
        self.assertEqual(result.status, "error")
        report = Path(result.archive).with_suffix(".error.txt")
        self.assertIn("แถว 3", report.read_text(encoding="utf-8"))
        self.assertEqual(len(self.service.products()), 0)

    def test_database_failure_rolls_back_products_and_success_history(self):
        # จำลองข้อผิดพลาดหลัง insert แถวแรก เพื่อยืนยัน transaction จริง
        with closing(self.service.connect()) as connection:
            connection.execute("""CREATE TRIGGER fail_second BEFORE INSERT ON products
                                  WHEN NEW.product_id = 'P002'
                                  BEGIN SELECT RAISE(ABORT, 'simulated failure'); END;""")
            connection.commit()
        with self.assertRaises(sqlite3.IntegrityError):
            self.initial()
        self.assertEqual(len(self.service.products()), 0)
        self.assertEqual(len(self.service.history()), 0)

    def test_archive_failure_keeps_committed_data_and_does_not_duplicate(self):
        source = self.root / "inbox" / "locked.xlsx"
        source.write_bytes(self.load("01_products.xlsx"))
        with patch("importer.shutil.move", side_effect=PermissionError("file locked")):
            with self.assertLogs("importer", level="WARNING"):
                result = self.service.process_file(source)
        self.assertEqual(result.status, "success")
        self.assertEqual(len(self.service.products()), 8)
        self.assertFalse(source.exists())
        self.assertEqual(len(list((self.root / "processing").glob("*.xlsx"))), 1)
        reopened = InventoryImporter(self.root)
        self.assertEqual(reopened.scan_once()[0].status, "duplicate")
        self.assertEqual(len(reopened.products()), 8)
        self.assertEqual(reopened.get_product("P001")["quantity"], 100)
        self.assertEqual(len(reopened.history()), 1)
        self.assertEqual(list((self.root / "processing").iterdir()), [])
        # ส่งไฟล์เดิมเข้ามาใหม่อย่างตั้งใจ ต้องนับเป็นการรับสินค้าอีกครั้ง
        source.write_bytes(self.load("01_products.xlsx"))
        self.assertEqual(reopened.scan_once()[0].status, "success")
        self.assertEqual(reopened.get_product("P001")["quantity"], 200)

    def test_legacy_unique_hash_index_migrates_without_losing_existing_data(self):
        self.initial()
        before = [tuple(row) for row in self.service.products()]
        with closing(self.service.connect()) as connection:
            connection.executescript("""
                DROP TABLE import_deliveries;
                CREATE UNIQUE INDEX one_success_per_hash
                ON import_history(file_hash) WHERE status='success';
            """)
        reopened = InventoryImporter(self.root)
        self.assertEqual([tuple(row) for row in reopened.products()], before)
        self.assertEqual(len(reopened.history()), 1)
        result = reopened.import_bytes("01_products.xlsx", self.load("01_products.xlsx"))
        self.assertEqual(result.status, "success")
        self.assertEqual(reopened.get_product("P001")["quantity"], 200)
        self.assertEqual(len(reopened.history()), 2)

    def test_interrupted_database_job_retries_once_with_receipt_after_restart(self):
        source = self.root / "inbox" / "delivery.xlsx"
        source.write_bytes(self.load("01_products.xlsx"))
        with closing(self.service.connect()) as connection:
            connection.executescript("""CREATE TRIGGER fail_second BEFORE INSERT ON products
                WHEN NEW.product_id='P002' BEGIN SELECT RAISE(ABORT, 'simulated failure'); END;""")
        with self.assertLogs("importer", level="ERROR"):
            self.assertEqual(self.service.scan_once()[0].status, "retry")
        self.assertEqual(self.service.products(), [])
        self.assertEqual(self.service.history(), [])
        with closing(self.service.connect()) as connection:
            self.assertEqual(connection.execute("SELECT COUNT(*) FROM import_deliveries").fetchone()[0], 0)
            connection.execute("DROP TRIGGER fail_second")
        reopened = InventoryImporter(self.root)
        self.assertEqual(reopened.scan_once()[0].status, "success")
        self.assertEqual(reopened.get_product("P001")["quantity"], 100)
        self.assertEqual(reopened.scan_once(), [])
        self.assertEqual(len(reopened.history()), 1)

    def test_concurrent_imports_preserve_both_deliveries(self):
        content = self.load("01_products.xlsx")
        with ThreadPoolExecutor(max_workers=2) as pool:
            results = list(pool.map(lambda n: self.service.import_bytes(f"{n}.xlsx", content), range(2)))
        self.assertEqual([r.status for r in results], ["success", "success"])
        self.assertEqual(self.service.get_product("P001")["quantity"], 200)
        self.assertEqual(len(self.service.history()), 2)

    def test_stock_overflow_rejects_entire_file_before_updates(self):
        self.initial()
        with closing(self.service.connect()) as connection:
            with connection:
                connection.execute("UPDATE products SET quantity=? WHERE product_id='P003'", (MAX_STOCK,))
        before = [tuple(row) for row in self.service.products()]
        result = self.service.import_bytes("more.xlsx", self.load("02_update.xlsx"))
        self.assertEqual(result.status, "error")
        self.assertIn("P003", result.message)
        self.assertEqual([tuple(row) for row in self.service.products()], before)

    def test_multiple_selected_files_continue_after_bad_file_and_keep_originals(self):
        sources = [PROJECT / "examples" / name for name in
                   ("01_products.xlsx", "03_invalid.xlsx", "02_update.xlsx", "01_products.xlsx")]
        results = self.service.import_selected_files(sources)
        self.assertEqual([r.status for r in results], ["success", "error", "success", "success"])
        self.assertEqual(self.service.get_product("P001")["quantity"], 320)
        self.assertEqual(self.service.get_product("P003")["quantity"], 170)
        self.assertTrue(all(path.is_file() for path in sources))
        self.assertEqual(len(self.service.products()), 9)
        self.assertEqual(len(self.service.history()), 4)


if __name__ == "__main__":
    unittest.main(verbosity=2)
