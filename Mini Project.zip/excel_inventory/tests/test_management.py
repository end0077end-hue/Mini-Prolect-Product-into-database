"""ตรวจการลบและส่งออกบนฐานข้อมูลชั่วคราว ไม่ใช้ฐานข้อมูลจริงของผู้ใช้."""

from contextlib import closing, redirect_stdout
from concurrent.futures import ThreadPoolExecutor
from io import StringIO
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

from openpyxl import load_workbook

from importer import HEADERS, InventoryImporter, InvalidData, now_text, read_products
from main import delete_inventory_item


PROJECT = Path(__file__).resolve().parents[1]


class ManagementTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.service = InventoryImporter(self.root)

    def initial(self):
        self.service.import_bytes("01_products.xlsx", (PROJECT / "examples" / "01_products.xlsx").read_bytes())

    def test_delete_only_selected_product_and_keep_history(self):
        self.initial()
        deleted = self.service.delete_product("P001")
        self.assertEqual(deleted["product_name"], "ปากกาลูกลื่น")
        reopened = InventoryImporter(self.root)
        self.assertIsNone(reopened.get_product("P001"))
        self.assertEqual([row["product_id"] for row in reopened.products()],
                         ["P002", "P003", "P004", "P005", "P006", "P007", "P008"])
        self.assertEqual(len(reopened.history()), 1)

    def test_missing_or_sql_like_id_cannot_delete_other_products(self):
        self.initial()
        for product_id in ("P999", "' OR 1=1 --", ""):
            with self.subTest(product_id=product_id):
                self.assertIsNone(self.service.get_product(product_id))
                self.assertIsNone(self.service.delete_product(product_id))
        self.assertEqual(len(self.service.products()), 8)

    def test_cancelled_confirmation_preserves_product(self):
        self.initial()
        with patch("builtins.input", side_effect=["P001", "n"]), redirect_stdout(StringIO()) as output:
            delete_inventory_item(self.service)
        self.assertIn("ยกเลิกการลบ", output.getvalue())
        self.assertEqual(len(self.service.products()), 8)

    def test_reduce_selected_quantity_persists_and_does_not_touch_other_products(self):
        self.initial()
        before = [tuple(row) for row in self.service.products() if row["product_id"] != "P001"]
        result = self.service.reduce_quantity("P001", 5)
        self.assertEqual((result.before, result.removed, result.after), (100, 5, 95))
        reopened = InventoryImporter(self.root)
        self.assertEqual(reopened.get_product("P001")["quantity"], 95)
        self.assertEqual([tuple(row) for row in reopened.products() if row["product_id"] != "P001"], before)
        self.assertEqual(len(reopened.history()), 1)

    def test_reduce_all_units_keeps_zero_stock_row_then_reupload_adds_stock(self):
        self.initial()
        result = self.service.reduce_quantity("P001", 100)
        self.assertEqual(result.after, 0)
        self.assertEqual(self.service.get_product("P001")["quantity"], 0)
        self.assertEqual(len(self.service.products()), 8)
        self.initial()
        self.assertEqual(self.service.get_product("P001")["quantity"], 100)
        self.assertEqual(self.service.get_product("P002")["quantity"], 160)

    def test_invalid_amounts_missing_ids_and_stale_selection_do_not_change_stock(self):
        self.initial()
        before = [tuple(row) for row in self.service.products()]
        for amount in (0, -1, 101, 1.5, "5", True, None):
            with self.subTest(amount=amount), self.assertRaises(InvalidData):
                self.service.reduce_quantity("P001", amount)
        self.assertIsNone(self.service.reduce_quantity("' OR 1=1 --", 1))
        self.assertEqual([tuple(row) for row in self.service.products()], before)
        old = self.service.get_product("P001")
        self.service.reduce_quantity("P001", 1)
        with self.assertRaises(InvalidData):
            self.service.reduce_quantity("P001", 10, expected=tuple(old))
        self.assertEqual(self.service.get_product("P001")["quantity"], 99)

    def test_concurrent_reductions_cannot_make_stock_negative(self):
        self.initial()
        def reduce(_):
            try:
                return self.service.reduce_quantity("P001", 60)
            except InvalidData:
                return None
        with ThreadPoolExecutor(max_workers=2) as pool:
            results = list(pool.map(reduce, range(2)))
        self.assertEqual(sum(r is not None for r in results), 1)
        self.assertEqual(self.service.get_product("P001")["quantity"], 40)

    def test_menu_quantity_removal_cancel_invalid_and_success(self):
        self.initial()
        run = subprocess.run(
            [sys.executable, str(PROJECT / "main.py"), "--data-dir", str(self.root)],
            input="7\nP001\n101\n7\nP001\n5\nn\n7\nP001\n5\ny\n0\n",
            text=True, capture_output=True, encoding="utf-8", timeout=20,
        )
        self.assertEqual(run.returncode, 0, run.stderr)
        self.assertIn("ลบตามจำนวนไม่สำเร็จ", run.stdout)
        self.assertIn("ยกเลิกการลบตามจำนวน", run.stdout)
        self.assertIn("P001 คงเหลือ 95 ชิ้น", run.stdout)
        self.assertEqual(self.service.get_product("P001")["quantity"], 95)

    def test_empty_database_does_not_export_empty_workbook(self):
        self.assertIsNone(self.service.export_products())
        self.assertEqual(list((self.root / "exports").iterdir()), [])

    def test_export_preserves_database_and_round_trips_text_and_money(self):
        self.initial()
        # ข้อมูลข้อความที่ขึ้นต้น = ต้องถูกส่งออกเป็นข้อความ ไม่กลายเป็นสูตร
        with closing(self.service.connect()) as connection:
            with connection:
                connection.execute("INSERT INTO products VALUES (?, ?, ?, ?, ?, ?)",
                                   ("001", "=SUM(1,1)", "+เอกสาร", 10, 0, now_text()))
        before = [tuple(row) for row in self.service.products()]
        history = [tuple(row) for row in self.service.history()]
        path, count = self.service.export_products()
        self.assertEqual(count, 9)
        self.assertEqual(path.parent, self.root / "exports")
        workbook = load_workbook(path, data_only=False)
        try:
            sheet = workbook["Products"]
            self.assertEqual(tuple(cell.value for cell in sheet[1]), HEADERS)
            self.assertEqual((sheet["A2"].value, sheet["A2"].data_type), ("001", "s"))
            self.assertEqual((sheet["B2"].value, sheet["B2"].data_type), ("=SUM(1,1)", "s"))
            self.assertEqual(sheet["D2"].value, 0.1)
            self.assertEqual(sheet["D2"].number_format, "#,##0.00")
            self.assertEqual(sheet.freeze_panes, "A2")
        finally:
            workbook.close()
        self.assertEqual(read_products(path.read_bytes()), [row[:5] for row in before])
        self.assertEqual([tuple(row) for row in self.service.products()], before)
        self.assertEqual([tuple(row) for row in self.service.history()], history)
        second, second_count = self.service.export_products()
        self.assertNotEqual(path, second)
        self.assertEqual(second_count, 9)
        self.assertTrue(path.exists() and second.exists())

    def test_export_failure_leaves_database_and_no_incomplete_xlsx(self):
        self.initial()
        with patch("importer.Workbook.save", side_effect=OSError("simulated write failure")):
            with self.assertRaises(OSError):
                self.service.export_products()
        self.assertEqual(list((self.root / "exports").iterdir()), [])
        self.assertEqual(len(self.service.products()), 8)

    def test_menu_export_cancel_delete_and_confirm_delete(self):
        self.initial()
        run = subprocess.run(
            [sys.executable, str(PROJECT / "main.py"), "--data-dir", str(self.root)],
            input="6\n5\nP001\nn\n5\nP001\ny\n3\n0\n",
            text=True, capture_output=True, encoding="utf-8", timeout=20,
        )
        self.assertEqual(run.returncode, 0, run.stderr)
        self.assertIn("ส่งออกสำเร็จ 8 รหัสสินค้า", run.stdout)
        self.assertIn("ยกเลิกการลบ", run.stdout)
        self.assertIn("ลบสินค้า P001 สำเร็จ", run.stdout)
        self.assertIn("รวม 7 รหัสสินค้า", run.stdout)
        self.assertEqual(len(self.service.products()), 7)
        exports = list((self.root / "exports").glob("*.xlsx"))
        self.assertEqual(len(exports), 1)
        self.assertEqual(len(read_products(exports[0].read_bytes())), 8)


if __name__ == "__main__":
    unittest.main(verbosity=2)
