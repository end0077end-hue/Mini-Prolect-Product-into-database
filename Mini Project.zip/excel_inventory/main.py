"""จุดเริ่มต้นของโปรแกรม: มีเมนูและโหมดเฝ้าโฟลเดอร์อัตโนมัติ."""

import argparse
import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path
import sqlite3
import sys
import time

try:
    from importer import InventoryImporter, InvalidData
except ModuleNotFoundError as exc:
    if exc.name != "openpyxl":
        raise
    raise SystemExit("กรุณาติดตั้งก่อน: python -m pip install -r requirements.txt") from exc


def print_results(results):
    labels = {"success": "สำเร็จ", "duplicate": "บันทึกไว้แล้ว", "error": "ข้อมูลผิด", "retry": "รอลองใหม่"}
    for result in results:
        print(f"[{labels[result.status]}] {result.filename}: {result.message}", flush=True)


def show_products(service):
    rows = service.products()
    if not rows:
        print("ยังไม่มีสินค้า กรุณานำเข้า Excel ก่อน")
        return
    print("\nรหัส | ชื่อสินค้า | หมวดหมู่ | ราคา (บาท) | จำนวน")
    for row in rows:
        price = f"{row['price_satang'] // 100:,}.{row['price_satang'] % 100:02d}"
        print(f"{row['product_id']} | {row['product_name']} | {row['category']} | {price} | {row['quantity']:,}")
    total_satang = sum(row["price_satang"] * row["quantity"] for row in rows)
    print(f"รวม {len(rows)} รหัสสินค้า | มูลค่าคงเหลือ {total_satang // 100:,}.{total_satang % 100:02d} บาท")


def show_history(service):
    rows = service.history()
    if not rows:
        print("ยังไม่มีประวัติการนำเข้า")
    for row in rows:
        print(f"{row['imported_at']} | {row['filename']} | {row['status']} | {row['message']}")


def watch(service, interval):
    print(f"\nกำลังตรวจ inbox ทุก {interval} วินาที: {service.root / 'inbox'}")
    print("วางไฟล์ .xlsx ที่บันทึกและปิดเรียบร้อยแล้ว | กด Ctrl+C เพื่อหยุด", flush=True)
    try:
        while True:
            print_results(service.scan_once(require_stable=True))
            time.sleep(interval)
    except KeyboardInterrupt:
        print("\nหยุดโหมดอัตโนมัติแล้ว")


def delete_inventory_item(service):
    """ให้เลือกและยืนยันรหัสสินค้าก่อนลบออกจากฐานข้อมูล."""
    try:
        product_id = input("รหัสสินค้าที่ต้องการลบ (Enter = ยกเลิก): ").strip()
        if not product_id:
            print("ยกเลิกการลบ")
            return
        product = service.get_product(product_id)
        if product is None:
            print(f"ไม่พบรหัสสินค้า {product_id}")
            return
        print(f"รายการที่จะลบ: {product['product_id']} | {product['product_name']} | คงเหลือ {product['quantity']:,} ชิ้น")
        confirm = input("ยืนยันลบสินค้านี้จากฐานข้อมูล? (y = ลบ / Enter = ยกเลิก): ").strip().lower()
        if confirm != "y":
            print("ยกเลิกการลบ")
            return
        deleted = service.delete_product(product_id, expected=tuple(product))
        if deleted is None:
            print("ไม่พบรายการนี้แล้ว กรุณาดูรายการสินค้าล่าสุดด้วยเมนู 3")
        else:
            print(f"ลบสินค้า {deleted['product_id']} สำเร็จ")
    except (EOFError, KeyboardInterrupt):
        print("\nยกเลิกการลบ")
    except (OSError, sqlite3.Error, InvalidData) as exc:
        logging.exception("ลบสินค้าไม่สำเร็จ")
        print(f"ลบสินค้าไม่สำเร็จ: {exc}")


def reduce_inventory_quantity(service):
    """เลือกรหัสและจำนวนชิ้นที่จะลบ โดยเก็บรหัสสินค้าไว้."""
    try:
        product_id = input("รหัสสินค้า (Enter = ยกเลิก): ").strip()
        if not product_id:
            return
        product = service.get_product(product_id)
        if product is None:
            print("ไม่พบรหัสสินค้านี้")
            return
        print(f"{product['product_id']} | {product['product_name']} | คงเหลือ {product['quantity']:,} ชิ้น")
        if product["quantity"] == 0:
            print("คงเหลือ 0 ชิ้น จึงยังลบจำนวนไม่ได้")
            return
        value = input("จำนวนชิ้นที่จะลบ (Enter = ยกเลิก): ").strip()
        if not value:
            return
        amount = int(value)
        if amount < 1 or amount > product["quantity"]:
            raise InvalidData(f"กรุณาใส่จำนวนตั้งแต่ 1 ถึง {product['quantity']:,}")
        print(f"ลบ {amount:,} ชิ้น → คงเหลือ {product['quantity'] - amount:,} ชิ้น")
        if input("ยืนยัน? (y = ลบ / Enter = ยกเลิก): ").strip().lower() != "y":
            print("ยกเลิกการลบตามจำนวน")
            return
        result = service.reduce_quantity(product_id, amount, expected=tuple(product))
        if result is None:
            print("ไม่พบสินค้านี้แล้ว กรุณาดูรายการล่าสุดด้วยเมนู 3")
        else:
            print(f"ลบ {result.removed:,} ชิ้นสำเร็จ | {result.product_id} คงเหลือ {result.after:,} ชิ้น")
    except (EOFError, KeyboardInterrupt):
        print("\nยกเลิกการลบตามจำนวน")
    except (ValueError, OSError, sqlite3.Error) as exc:
        print(f"ลบตามจำนวนไม่สำเร็จ: {exc}")


def export_inventory(service):
    """อ่านข้อมูลจากฐานข้อมูล แล้วสร้าง Excel ในโฟลเดอร์ exports."""
    try:
        result = service.export_products()
        if result is None:
            print("ยังไม่มีสินค้าให้ส่งออก กรุณานำเข้าข้อมูลก่อน")
            return
        path, count = result
        print(f"ส่งออกสำเร็จ {count} รหัสสินค้า")
        print(f"ไฟล์ Excel: {path}")
    except (OSError, sqlite3.Error) as exc:
        logging.exception("ส่งออกข้อมูลไม่สำเร็จ")
        print(f"ส่งออกข้อมูลไม่สำเร็จ: {exc}")


def menu(service, interval):
    while True:
        print("\n=== ระบบนำเข้าสินค้าจาก Excel อัตโนมัติ ===")
        print("1. เริ่มโหมดอัตโนมัติ\n2. นำเข้าไฟล์ใน inbox (บวกจำนวนเพิ่ม)\n3. ดูรายการสินค้า\n4. ดูประวัติ 20 ครั้งล่าสุด\n5. ลบรหัสสินค้าทั้งรายการ\n6. ส่งออกสินค้าเป็น Excel\n7. ลบสินค้าตามจำนวน\n0. ออกจากโปรแกรม")
        try:
            choice = input("เลือกเมนู: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nปิดโปรแกรม")
            return
        if choice == "1":
            watch(service, interval)
        elif choice == "2":
            results = service.scan_once()
            print_results(results)
            if not results:
                print("ไม่มีไฟล์ .xlsx ใหม่ใน inbox")
        elif choice == "3":
            show_products(service)
        elif choice == "4":
            show_history(service)
        elif choice == "5":
            delete_inventory_item(service)
        elif choice == "6":
            export_inventory(service)
        elif choice == "7":
            reduce_inventory_quantity(service)
        elif choice == "0":
            return
        else:
            print("กรุณาเลือก 0 ถึง 7")


def main():
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8")
    parser = argparse.ArgumentParser(description="นำเข้าสินค้าจาก Excel ไปยัง SQLite")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--once", action="store_true", help="นำเข้า inbox ครั้งเดียว")
    mode.add_argument("--watch", action="store_true", help="เฝ้าโฟลเดอร์อัตโนมัติ")
    mode.add_argument("--show", action="store_true", help="แสดงสินค้าในฐานข้อมูล")
    mode.add_argument("--history", action="store_true", help="แสดงประวัติการนำเข้า")
    parser.add_argument("--interval", type=int, default=5, help="ตรวจทุกกี่วินาที (ค่าเริ่มต้น 5)")
    parser.add_argument("--data-dir", type=Path, default=Path(__file__).resolve().parent,
                        help="โฟลเดอร์เก็บ inbox และฐานข้อมูล")
    args = parser.parse_args()
    if args.interval < 1:
        parser.error("--interval ต้องเป็นจำนวนเต็มอย่างน้อย 1")
    try:
        service = InventoryImporter(args.data_dir)
        handler = RotatingFileHandler(service.root / "logs" / "system.log",
                                      maxBytes=1_000_000, backupCount=2, encoding="utf-8")
        logging.basicConfig(level=logging.INFO, handlers=[handler],
                            format="%(asctime)s %(levelname)s %(message)s")
        if args.once:
            results = service.scan_once()
            print_results(results)
            if not results:
                print("ไม่มีไฟล์ .xlsx ใหม่ใน inbox")
            return int(any(result.status in ("error", "retry") for result in results))
        if args.watch:
            watch(service, args.interval)
        elif args.show:
            show_products(service)
        elif args.history:
            show_history(service)
        else:
            menu(service, args.interval)
    except (OSError, sqlite3.Error) as exc:
        print(f"เปิดระบบไม่สำเร็จ: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
