@echo off
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
    py -3 -m venv .venv
) else (
    python -m venv .venv
)
if errorlevel 1 goto error
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto error
echo Setup complete. Open run_windows.bat to start.
pause
exit /b 0
:error
echo Setup failed. Install Python 3.10+ and check your internet connection.
pause
exit /b 1
